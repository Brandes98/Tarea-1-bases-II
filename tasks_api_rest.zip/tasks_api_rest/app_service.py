import json
from db import Database

class AppService:

    def __init__(self, database: Database):
        self.database = database

    def create_task(self, task):
        self.database.create_task(task)
        return task

    def get_tasks(self):
        data = self.database.get_tasks()
        return data
    
    def get_task_ids(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT id FROM tasks;")
        data = cursor.fetchall()
        cursor.close()
        return [row[0] for row in data]  # Extraer los IDs de la lista de tuplas

    def update_task(self, id, task_json):
        self.database.update_task(id, task_json)
        return task_json

    def delete_task(self, task_id):
        self.database.delete_task(task_id)
        return task_id

    def register_user(self, username, password):
        return self.database.create_user(username, password)
    
    def authenticate_user(self, username, password):
        user = self.database.get_user_by_username(username)
        if user and user[1] == password:
            return user
        return None

     
    def get_user_ids(self):
        # Lógica para obtener los IDs de usuario desde la base de datos
        # Supongamos que tienes un método en tu base de datos para obtener los IDs de usuario
        user_ids = self.database.get_user_ids()  # Implementa este método en tu clase Database
        return user_ids