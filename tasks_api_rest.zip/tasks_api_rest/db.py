import psycopg2


class Database:
    def __init__(
        self, database="db_name", host="db_host", user="db_user", password="db_pass", port="db_port"
    ):
        self.conn = psycopg2.connect(
            database=database, host=host, user=user, password=password, port=port
        )

    def create_task(self, task_json):
        cursor = self.conn.cursor()
        cursor.execute(
            f"INSERT INTO tasks (title, description, due_date, status, usuario_id) VALUES ('{task_json['title']}', '{task_json['description']}', '{task_json['due_date']}', '{task_json['status']}', '{task_json['usuario_id']}');"
        )
        self.conn.commit()
        cursor.close()
        return task_json

    def get_tasks(self):
        cursor = self.conn.cursor()
        cursor.execute("SELECT id, title, description, due_date, status, usuario_id FROM tasks;")
        data = cursor.fetchall()
        cursor.close()
        return data
    
    def get_task_by_id(self, id):
        cursor = self.conn.cursor()
        cursor.execute(f"SELECT id, title, description, due_date, status, usuario_id FROM tasks WHERE id = {id};")
        data = cursor.fetchall()
        cursor.close()
        return data

    def update_task(self, id, task_json):
        cursor = self.conn.cursor()
        cursor.execute(
            f"UPDATE tasks SET title = '{task_json['title']}', description = '{task_json['description']}', due_date = '{task_json['due_date']}', status = '{task_json['status']}', usuario_id = '{task_json['usuario_id']}' WHERE id = {id};"
        )
        self.conn.commit()
        cursor.close()
        return task_json

    def delete_task(self, id):
        cursor = self.conn.cursor()
        cursor.execute(f"DELETE FROM tasks WHERE id = {id};")
        self.conn.commit()
        cursor.close()
        return id