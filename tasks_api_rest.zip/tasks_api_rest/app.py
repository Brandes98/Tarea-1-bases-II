import json
import os

from app_service import AppService
from db import Database
from flask import Flask, request, jsonify
from flask import Flask, render_template, url_for
from flask_login import UserMixin
#from flask_wtf import FlaskForm
#from wtforms import StringField, PasswordField, SubmitField
#from wtforms.validators import InputRequired, Length, ValidationError


DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")

print(DB_NAME, DB_HOST, DB_USER, DB_PASSWORD, DB_PORT)

db = Database(database=DB_NAME, host=DB_HOST, user=DB_USER, password=DB_PASSWORD, port=DB_PORT)

app = Flask(__name__)
appService = AppService(db)



#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
#app.config['SECRET_KEY'] = 'thisisasecretkey'





#class User(db.Model, UserMixin):
#    id = db.Column(db.Integer, primary_key=True)
#    username = db.Column(db.String(20), nullable=False, unique=True)
#    password = db.Column(db.String(80), nullable=False)
""""    
class RegisterForm(FlaskForm):
    username = StringField(validators=[
                           InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[
                             InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField('Register')


    def validate_username(self, username):
            existing_user_username = User.query.filter_by(
                username=username.data).first()
            if existing_user_username:
                raise ValidationError(
                    'That username already exists. Please choose a different one.')
class LoginForm(FlaskForm):
    username = StringField(validators=[
                           InputRequired(), Length(min=4, max=20)], render_kw={"placeholder": "Username"})

    password = PasswordField(validators=[
                             InputRequired(), Length(min=8, max=20)], render_kw={"placeholder": "Password"})

    submit = SubmitField('Login')
"""
@app.route("/")
def home():
    return render_template("home.html")

@app.route("/login")#, methods=['GET', 'POST'])
def login():
    #form = LoginForm()
    return render_template("login.html")#, form=form)

@app.route("/register")#, methods=['GET', 'POST'])
def register():
    #form = RegisterForm()
    return render_template("register.html")#, form=form)

@app.route("/tasks", methods=["POST"])
def create_task():
    request_data = request.get_json()
    return appService.create_task(request_data)

@app.route("/tasks")
def tasks():
    return appService.get_tasks()

@app.route("/tasks/<int:id>")
def task_by_id(id):
    return appService.get_task_by_id(id)

@app.route("/tasks/<int:id>", methods=["PUT"])
def update_task(id):
    request_data = request.get_json()
    return appService.update_task(id, request_data)

@app.route("/tasks/<int:id>", methods=["DELETE"])
def delete_task(id):
    return appService.delete_task(str(id))