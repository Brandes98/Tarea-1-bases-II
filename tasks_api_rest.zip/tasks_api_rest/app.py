import os
from flask import Flask, request, render_template, session, redirect, url_for
from flask import jsonify
from app_service import AppService
from db import Database


DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")


db = Database(database=DB_NAME, host=DB_HOST, user=DB_USER, password=DB_PASSWORD, port=DB_PORT)


app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Asegúrate de cambiar esto por una clave secreta segura

appService = AppService(db)


@app.route("/")
def home():
    return render_template("home.html")

@app.route("/user_ids")
def get_user_ids():
    user_ids = appService.get_user_ids()  
    return jsonify(user_ids)

@app.route("/main_page")
def main_page():
    return render_template("main_page.html")

@app.route("/main_menu")
def main_menu():
    return render_template("main_menu.html")


@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
       
        user = appService.authenticate_user(username, password)
        if user:
            
            session['username'] = username
            return redirect(url_for('main_menu'))
        else:
            
            return 'Credenciales inválidas. <a href="/login">Intentar de nuevo</a>'
    return render_template("login.html")


@app.route("/register", methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Registra el usuario en la base de datos
        success = appService.register_user(username, password)
        if success:
            # Redirige a la página de inicio de sesión si el registro es exitoso
            return redirect(url_for('login'))
        else:
            # Muestra un mensaje de error si el nombre de usuario ya está en uso
            return 'El nombre de usuario ya está en uso. <a href="/register">Intentar de nuevo</a>'
    return render_template("register.html")




@app.route("/tasks", methods=["POST"])
def create_task():
    
    request_data = request.get_json()
    if 'usuario_id' in request_data:
        
        usuario_id = request_data['usuario_id']
        return appService.create_task(request_data)
    

    

@app.route("/tasks")
def tasks():
    tasks_data = appService.get_tasks()  
    return render_template("tasks.html", tasks=tasks_data)


@app.route("/task_ids")
def task_ids():
    task_ids = appService.get_task_ids()
    return jsonify(task_ids)



@app.route("/tasks/<int:id>", methods=["PUT"])
def update_task(id):
    request_data = request.get_json()
    return appService.update_task(id, request_data)

@app.route("/tasks/<int:id>", methods=["DELETE"])
def delete_task(id):
    return appService.delete_task(str(id))

if __name__ == '__main__':
    app.run(debug=True)
