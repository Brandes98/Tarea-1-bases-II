CREATE DATABASE tasks;

\c tasks;

CREATE TABLE tasks (
  id SERIAL PRIMARY KEY,
  title VARCHAR NOT NULL,
  description VARCHAR NOT NULL,
  due_date DATE NOT NULL,
  status BOOLEAN NOT NULL,
  usuario_id INTEGER NOT NULL
);